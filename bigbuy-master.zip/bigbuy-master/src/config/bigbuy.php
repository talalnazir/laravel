<?php

return [   
    'server' => env('BIGBUY_HOST','https://api.sandbox.bigbuy.eu'), 
    'timeout' => 60.0,
    'token' => env('BIGBUY_TOKEN',''),
];